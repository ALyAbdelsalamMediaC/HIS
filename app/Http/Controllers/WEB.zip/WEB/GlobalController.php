<?php

namespace App\Http\Controllers\WEB;

use App\Http\Controllers\Controller;
use App\Models\Article;
use App\Models\Media;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class GlobalController extends Controller
{
    public function globalSearch(Request $request)
    {
        try {
            $searchTerm = $request->input('search');
            $user = Auth::user();

            // Initialize variables
            $articles = collect();
            $videos = collect();

            // Filter based on user role
            if ($user->role === 'reviewer') {
                // For reviewers: only show videos they're assigned to, no articles
                $videos = Media::where('title', 'like', '%' . $searchTerm . '%')
                    ->where(function($query) use ($user) {
                        $query->whereJsonContains('assigned_to', $user->id);
                    })
                    ->get();
            } else {
                // For other roles (admin, user): show all articles and videos
                $articles = Article::where('title', 'like', '%' . $searchTerm . '%')->get();
                $videos = Media::where('title', 'like', '%' . $searchTerm . '%')->get();
            }

            if ($request->has('ajax')) {
                $articlesArr = $articles->map(function($a) {
                    return [
                        'id' => $a->id,
                        'title' => $a->title,
                        'thumbnail' => $a->thumbnail ?? $a->thumbnail_path ?? null,
                        'created_at' => optional($a->created_at)->toDateString(),
                    ];
                });
                $videosArr = $videos->map(function($v) {
                    return [
                        'id' => $v->id,
                        'title' => $v->title,
                        'thumbnail' => $v->thumbnail ?? $v->thumbnail_path ?? null,
                        'created_at' => optional($v->created_at)->toDateString(),
                        'status' => $v->status ?? 'published',
                    ];
                });
                return response()->json([
                    'articles' => $articlesArr,
                    'videos' => $videosArr,
                ]);
            }

            return view('pages.search.results', [
                'articles' => $articles,
                'videos' => $videos,
                'searchTerm' => $searchTerm,
            ]);
        } catch (\Exception $e) {
            return redirect()->back()->with('error', 'An error occurred during search.');
        }
    }
}
